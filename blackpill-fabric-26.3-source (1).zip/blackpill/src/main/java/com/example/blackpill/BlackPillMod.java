package com.example.blackpill;

import net.fabricmc.api.ModInitializer;

public class BlackPillMod implements ModInitializer {
    public static final String MOD_ID = "blackpill";

    @Override
    public void onInitialize() {
        ModSounds.init();
        ModEffects.init();
        ModItems.init();
        GiantEvents.register();
        PillEvents.register();
    }
}
