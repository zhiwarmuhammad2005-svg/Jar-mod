package com.example.blackpill;

import net.minecraft.client.Minecraft;
import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.MobEffect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client side. Owns the ONE music instance that can exist at a time.
 *
 * Which track plays is decided only by the local player's effects:
 *   Shrunk only   -> Black Pill track
 *   Uplifted only -> White Pill track
 *   neither       -> silence
 * Switching always stops the old instance before the new one starts, so tracks can never overlap,
 * and a track that is already playing is never started again, so it can never double up.
 *
 * Every start/stop is written to the game log (search latest.log for "blackpill").
 */
final class PillMusic {
    private PillMusic() {}

    private static final Logger LOGGER = LoggerFactory.getLogger("blackpill");

    private enum Track { BLACK, WHITE }

    private static PillMusicInstance current;
    private static Track currentTrack;

    static void tick(Minecraft client) {
        // Our instance stops itself when its effect ends. Forget it so a new one can start later.
        if (current != null && current.isStopped()) {
            LOGGER.info("Pill music ended ({})", currentTrack);
            current = null;
            currentTrack = null;
        }

        Track wanted = null;
        var player = client.player;
        if (player != null) {
            boolean black = player.hasEffect(ModEffects.SHRUNK);
            boolean white = player.hasEffect(ModEffects.UPLIFTED);
            if (black && !white) {
                wanted = Track.BLACK;
            } else if (white && !black) {
                wanted = Track.WHITE;
            } else if (black) {
                // Both for a moment while the server swaps pills: keep whatever is playing.
                wanted = currentTrack;
            }
        }
        // player == null (left the world, still loading): wanted stays null, so music stops.

        if (wanted == currentTrack) {
            return;
        }

        stopCurrent(client);
        if (wanted != null) {
            start(client, wanted);
        }
    }

    private static void start(Minecraft client, Track track) {
        Holder<SoundEvent> sound = track == Track.BLACK ? ModSounds.PILL_SONG : ModSounds.WHITE_PILL_SONG;
        Holder<MobEffect> owner = track == Track.BLACK ? ModEffects.SHRUNK : ModEffects.UPLIFTED;
        current = new PillMusicInstance(sound.value(), owner);
        currentTrack = track;
        LOGGER.info("Starting {} pill music ({})", track,
                track == Track.BLACK ? ModSounds.PILL_SONG_ID : ModSounds.WHITE_PILL_SONG_ID);
        client.getSoundManager().play(current);
    }

    private static void stopCurrent(Minecraft client) {
        if (current != null) {
            LOGGER.info("Stopping {} pill music", currentTrack);
            current.halt();
            client.getSoundManager().stop(current);
        }
        current = null;
        currentTrack = null;
    }
}
