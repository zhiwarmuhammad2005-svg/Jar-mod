# Black Pill (Fabric, Minecraft 26.3)

Two items:

**Black Pill** - a small consumable that gives Night Vision (3 min), Resistance II (30 s) and Slowness I (30 s).

**Giant Hammer** - a heavy melee weapon (about 8 damage, slow swing). Right-click toggles giant mode:
- You grow to 3.0 blocks tall (the size attribute also widens you to 1.0 block; it cannot be made 1.8 wide without a custom hitbox).
- Villagers give you their lowest possible prices (Hero of the Village at level 20, re-applied while you are giant).
- Mobs cannot damage you, and hostile or neutral mobs within 48 blocks drop any grudge against you.
- Right-click again to go back to normal size. You will not fit through normal 2-block doors while giant.
- Turning giant mode on plays a song (`assets/blackpill/sounds/hammer_song.ogg`, 3:39) that follows you; turning it off stops it. To swap the song, replace that .ogg file (Vorbis format).
- Recipe: 5 iron ingots + 1 black pill + 1 stick (`III / IPI / .S.`).

- Item ID: `blackpill:black_pill`, stacks to 16, 1 s eat time, always edible, 1 s cooldown.
- Recipe (shapeless): coal + ink sac + bone meal -> 2 black pills.
- Creative tab: Food & Drinks.

## Install

1. Install Minecraft 26.3 with Fabric Loader 0.19.5 or newer (Java 25).
2. Download Fabric API for 26.3 (0.165.0+26.3 or newer).
3. Put Fabric API and `blackpill-1.0.0.jar` in your `mods` folder.

## Build

Needs JDK 25.

    ./gradlew build

The jar is in `build/libs/blackpill-1.0.0.jar` (not the `-sources` jar).

No JDK? Push this folder to a GitHub repo. The included workflow (`.github/workflows/build.yml`) builds it, and the jar is under Actions > latest run > Artifacts.
