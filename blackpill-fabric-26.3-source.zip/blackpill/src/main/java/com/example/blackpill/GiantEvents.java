package com.example.blackpill;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.player.Player;

/** Server-side rules that apply while a player is in giant mode. */
public final class GiantEvents {
    private GiantEvents() {}

    private static final double CALM_RADIUS = 48.0;

    public static void register() {
        // Mobs (and their projectiles or explosions) cannot hurt a giant player.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) ->
                !(entity instanceof Player
                        && GiantHammerItem.isGiant(entity)
                        && source.getEntity() instanceof Mob));

        ServerTickEvents.END_SERVER_TICK.register(GiantEvents::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        if (server.getTickCount() % 10 != 0) {
            return;
        }

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!GiantHammerItem.isGiant(player)) {
                continue;
            }

            // Re-apply the villager discount if it was cleared (milk, commands, death).
            if (!player.hasEffect(MobEffects.HERO_OF_THE_VILLAGE)) {
                GiantHammerItem.applyHero(player);
            }

            // Make nearby mobs drop any grudge against this player.
            for (Mob mob : player.level().getEntitiesOfClass(
                    Mob.class, player.getBoundingBox().inflate(CALM_RADIUS))) {
                if (mob.getTarget() == player) {
                    mob.setTarget(null);
                    if (mob instanceof NeutralMob neutral) {
                        neutral.stopBeingAngry();
                    }
                }
            }
        }
    }
}
