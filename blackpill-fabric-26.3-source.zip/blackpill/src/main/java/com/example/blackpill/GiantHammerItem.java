package com.example.blackpill;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/**
 * Right-click toggles "giant mode":
 *  - you grow to 3.0 blocks tall (the scale attribute also makes you wider, 1.0 block)
 *  - villagers give you their cheapest prices (Hero of the Village at a high level)
 *  - hostile and neutral mobs leave you alone (see GiantEvents)
 */
public class GiantHammerItem extends Item {
    public static final Identifier GIANT_SCALE_ID =
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "giant_scale");

    // Default player height is 1.8 blocks. 3.0 / 1.8 = 1.667 scale, so add 0.667 to the base of 1.0.
    private static final double SCALE_BONUS = 3.0 / 1.8 - 1.0;

    // Hero of the Village gives 30% + 6.25% per level off. Level 20 is far past 100%, so every
    // trade is clamped to its minimum price.
    private static final int HERO_AMPLIFIER = 20;

    public GiantHammerItem(Properties properties) {
        super(properties);
    }

    public static boolean isGiant(LivingEntity entity) {
        AttributeInstance scale = entity.getAttribute(Attributes.SCALE);
        return scale != null && scale.hasModifier(GIANT_SCALE_ID);
    }

    public static void applyHero(LivingEntity entity) {
        entity.addEffect(new MobEffectInstance(
                MobEffects.HERO_OF_THE_VILLAGE,
                MobEffectInstance.INFINITE_DURATION,
                HERO_AMPLIFIER,
                false,  // ambient
                true,   // show particles
                true)); // show icon
    }

    // Short message above the hotbar.
    private static void actionBar(Player player, Component message) {
        if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.connection.send(new ClientboundSetActionBarTextPacket(message));
        }
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }

        AttributeInstance scale = player.getAttribute(Attributes.SCALE);
        if (scale == null) {
            return InteractionResult.PASS;
        }

        if (scale.hasModifier(GIANT_SCALE_ID)) {
            scale.removeModifier(GIANT_SCALE_ID);
            player.removeEffect(MobEffects.HERO_OF_THE_VILLAGE);
            actionBar(player, Component.translatable("message.blackpill.giant_off"));
            // Stop the song for everyone who is hearing it.
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.getServer().getPlayerList().broadcastAll(
                        new ClientboundStopSoundPacket(ModSounds.HAMMER_SONG_ID, SoundSource.PLAYERS));
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.6f, 1.4f);
        } else {
            scale.addPermanentModifier(new AttributeModifier(
                    GIANT_SCALE_ID, SCALE_BONUS, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
            applyHero(player);
            actionBar(player, Component.translatable("message.blackpill.giant_on"));
            // Play the song. Passing the entity makes the sound follow the player around.
            level.playSound(null, player, ModSounds.HAMMER_SONG, SoundSource.PLAYERS, 1.0f, 1.0f);
        }

        player.getCooldowns().addCooldown(player.getItemInHand(hand), 20);
        return InteractionResult.SUCCESS;
    }
}
