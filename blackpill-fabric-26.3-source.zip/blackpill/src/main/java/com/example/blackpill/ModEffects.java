package com.example.blackpill;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;

public final class ModEffects {
    private ModEffects() {}

    public static final Holder<MobEffect> SHRUNK = Registry.registerForHolder(
            BuiltInRegistries.MOB_EFFECT,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "shrunk"),
            new ShrunkEffect());

    public static void init() {
        // Touching this class registers the effect.
    }
}
