package com.example.blackpill;

import java.util.List;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;

public final class ModItems {
    private ModItems() {}

    public static final ResourceKey<Item> BLACK_PILL_KEY = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "black_pill"));

    public static final Item BLACK_PILL = Registry.register(
            BuiltInRegistries.ITEM,
            BLACK_PILL_KEY,
            new Item(new Item.Properties()
                    .setId(BLACK_PILL_KEY)
                    .stacksTo(16)
                    .useCooldown(1.0f)
                    // Always edible, no hunger or saturation.
                    .food(new FoodProperties.Builder()
                            .nutrition(0)
                            .saturationModifier(0.0f)
                            .alwaysEdible()
                            .build(),
                            Consumable.builder()
                                    .consumeSeconds(1.0f)
                                    .animation(ItemUseAnimation.EAT)
                                    .sound(SoundEvents.GENERIC_EAT)
                                    .hasConsumeParticles(true)
                                    .onConsume(new ApplyStatusEffectsConsumeEffect(List.of(
                                            // Night Vision, 3 minutes
                                            new MobEffectInstance(MobEffects.NIGHT_VISION, 20 * 60 * 3, 0),
                                            // Resistance II, 30 seconds
                                            new MobEffectInstance(MobEffects.RESISTANCE, 20 * 30, 1),
                                            // Slowness I, 30 seconds
                                            new MobEffectInstance(MobEffects.SLOWNESS, 20 * 30, 0))))
                                    .build())));

    public static final ResourceKey<Item> GIANT_HAMMER_KEY = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "giant_hammer"));

    public static final Item GIANT_HAMMER = Registry.register(
            BuiltInRegistries.ITEM,
            GIANT_HAMMER_KEY,
            new GiantHammerItem(new Item.Properties()
                    .setId(GIANT_HAMMER_KEY)
                    .rarity(Rarity.EPIC)
                    // Heavy melee weapon: ~8 damage, slow swing.
                    .sword(ToolMaterial.IRON, 5.0f, -3.0f)));

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS)
                .register(entries -> entries.accept(BLACK_PILL));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(GIANT_HAMMER));
    }
}
