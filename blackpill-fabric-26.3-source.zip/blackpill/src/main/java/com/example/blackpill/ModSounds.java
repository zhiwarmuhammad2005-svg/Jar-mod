package com.example.blackpill;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class ModSounds {
    private ModSounds() {}

    public static final Identifier HAMMER_SONG_ID =
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "hammer_song");

    // Matches the "hammer_song" entry in assets/blackpill/sounds.json
    public static final SoundEvent HAMMER_SONG = Registry.register(
            BuiltInRegistries.SOUND_EVENT,
            HAMMER_SONG_ID,
            SoundEvent.createVariableRangeEvent(HAMMER_SONG_ID));

    public static final Identifier PILL_SONG_ID =
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "pill_song");

    // Matches the "pill_song" entry in sounds.json. Played when the pill is eaten.
    public static final Holder<SoundEvent> PILL_SONG = Registry.registerForHolder(
            BuiltInRegistries.SOUND_EVENT,
            PILL_SONG_ID,
            SoundEvent.createVariableRangeEvent(PILL_SONG_ID));

    public static void init() {
        // Touching this class registers the sounds.
    }
}
