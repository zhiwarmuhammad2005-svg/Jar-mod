package com.example.blackpill;

import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * Makes the player 0.5 blocks shorter (1.8 -> 1.3). The size attribute scales height and
 * width together, so width drops from 0.6 to about 0.43, not by a full 0.3.
 */
public class ShrunkEffect extends MobEffect {
    public static final Identifier SCALE_MODIFIER_ID =
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "shrunk_scale");

    // 1.3 / 1.8 = 0.722 scale, so add -0.278 to the base of 1.0.
    private static final double SCALE_CHANGE = 1.3 / 1.8 - 1.0;

    public ShrunkEffect() {
        super(MobEffectCategory.NEUTRAL, 0x3A3A46);
        addAttributeModifier(Attributes.SCALE, SCALE_MODIFIER_ID, SCALE_CHANGE,
                AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
    }
}
